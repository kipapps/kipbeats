<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @author    xvelopers
 * @package   rekord
 * @version   1.0.0
 */
?>
</div>
<!--@page-content-->
</div>
<!--@#app-->
<?php wp_footer(); ?>
</body>

</html>