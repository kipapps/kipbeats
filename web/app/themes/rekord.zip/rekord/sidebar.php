<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @author    xvelopers
 * @package   rekord
 * @version   1.0.0
 */
?>
<aside class="site-sidebar push-up">
    <?php dynamic_sidebar('default'); ?>
</aside><!-- #secondary -->