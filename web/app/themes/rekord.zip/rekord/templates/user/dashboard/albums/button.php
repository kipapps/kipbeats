<div class="d-flex my-3">
    <a href="<?php echo esc_url( get_page_link(get_theme_mod('page_album_save')) ); ?>"
        class="btn btn-outline-primary"><?php esc_html_e('Add New Album', 'rekord'); ?></a>
</div>