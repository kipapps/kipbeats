<div>
    <p><?php esc_html_e( 'You have not any albums yet.', 'rekord' ); ?>
    </p>
    <?php get_template_part('templates/user/dashboard/albums/button'); ?>
</div>