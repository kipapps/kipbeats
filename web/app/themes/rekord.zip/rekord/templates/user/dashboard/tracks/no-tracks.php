<div>
    <p><?php esc_html_e( 'You have not uploaded any tracks yet.', 'rekord' ); ?>
    </p>
    <?php get_template_part('templates/user/dashboard/tracks/button'); ?>
</div>