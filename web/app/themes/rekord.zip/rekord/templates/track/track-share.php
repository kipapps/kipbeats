<?php 
get_template_part('templates/global/social', 'share'); ?>