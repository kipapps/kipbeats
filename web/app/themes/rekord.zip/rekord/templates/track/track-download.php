<?php
/**
 *
 * @author    xvelopers
 * @package   rekord
 * @version   1.0.0
 */

?>


<a class="no-ajaxy" href="<?php echo rekord_get_field('track_upload')['url']; ?>" download><i class="icon-download"></i></a>