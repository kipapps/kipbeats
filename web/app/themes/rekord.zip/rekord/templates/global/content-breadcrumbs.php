<?php
/**
 *
 *  @author    xvelopers
 *  @package   rekord
 *  @version   1.0.0
 *  @since     1.0.0
 */
?>

<?php
if (function_exists('xv_breadcrumbs')){ ?>
<div class="breadcrumbs">
    <div class="container">
        <?php echo rekord_breadcrumbs(); ?>
    </div>
</div>
<?php } ?>