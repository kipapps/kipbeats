<?php
/**
 *
 *  @author    xvelopers
 *  @package   rekord
 *  @version   1.0.0
 *  @since     1.0.0
 */
?>
<div class="ml-auto s-plugins">
    <?php get_template_part('templates/favourites/favourites', 'button'); ?>
    <?php get_template_part('templates/global/social', 'share'); ?>
</div>