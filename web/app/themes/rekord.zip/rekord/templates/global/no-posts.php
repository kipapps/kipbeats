<div class="col-md-12 my-5 text-center">
    <div class="pt-5 p-t-100 text-center">
        <i class="icon-document s-36 text-primary"></i>
        <h4 class="text-primary mt-3"><?php esc_html_e('Nothing Here!','rekord'); ?></h4>
        <p class="section-subtitle">
            <?php esc_html_e( 'No posts found perhaps searching can help you!', 'rekord' ); ?></p>
    </div>
</div>